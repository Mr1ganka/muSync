package com.mu.sync.backend.muSync;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MuSyncApplication {

	public static void main(String[] args) {
		SpringApplication.run(MuSyncApplication.class, args);
	}

}
