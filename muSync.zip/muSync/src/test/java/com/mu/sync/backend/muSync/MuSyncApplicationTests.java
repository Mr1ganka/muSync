package com.mu.sync.backend.muSync;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MuSyncApplicationTests {

	@Test
	void contextLoads() {
	}

}
